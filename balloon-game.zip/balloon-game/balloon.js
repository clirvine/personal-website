var balloon = $(".balloon");
	for(var i=0; i<10; i++){
	  var balloonCopy = balloon.clone();
	  balloonCopy.css({
	  	left: i * 200
	  })
	  balloonCopy.appendTo("body");
	  balloonCopy.click(function(){
	  	$(this).remove();
	  };
	};
	balloon.remove();
